TrueDark Resource Pack (1.21.x)
Install server-side: set resource-pack URL + require-resource-pack=true. Set Purpur ambient-light: 0.0. Remove Night Vision if desired.
